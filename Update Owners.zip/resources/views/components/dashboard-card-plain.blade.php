<div class="p-5 {{ $bg ?? 'bg-red-100' }} border rounded shadow-lg">
    {{ $slot }}
</div>
