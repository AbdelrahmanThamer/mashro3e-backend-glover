@section('title', __('Loyalty Point Report') )
<div>

    <x-baseview title="{{ __('Loyalty Point Report') }}">
        <livewire:tables.reports.loyalty-point-report-table />
    </x-baseview>

</div>
