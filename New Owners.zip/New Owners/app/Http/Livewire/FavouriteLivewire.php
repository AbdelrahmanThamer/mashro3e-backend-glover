<?php

namespace App\Http\Livewire;


class FavouriteLivewire extends BaseLivewireComponent
{

    public function render()
    {
        return view('livewire.favourites');
    }

}
