<?php

namespace App\Http\Livewire;

class DriverEarningHistoryLivewire extends BaseLivewireComponent
{

    public function render()
    {
        return view('livewire.driver_earnings_history');
    }


}
