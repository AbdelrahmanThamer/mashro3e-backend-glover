<?php

namespace App\Http\Livewire;


class VendorEarningHistoryLivewire extends BaseLivewireComponent
{

    public function render()
    {
        return view('livewire.vendor_earnings_history');
    }

}
