<?php

namespace App\Models;


class Payment extends NoDeleteBaseModel
{
    
}
