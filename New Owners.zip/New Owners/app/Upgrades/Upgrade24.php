<?php

namespace App\Upgrades;

use App\Models\VendorType;
use App\Models\Order;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schema;

class Upgrade24 extends BaseUpgrade
{

    public $versionName = "1.4.0";
    //Runs or migrations to be done on this version
    public function run()
    {

       
    }


   
}
