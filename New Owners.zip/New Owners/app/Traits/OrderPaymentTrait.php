<?php

namespace App\Traits;

use App\Models\Order;
use App\Models\PaymentMethod;

trait OrderPaymentTrait
{

    public function handleOrderPayment(Order $order,PaymentMethod $paymentMethod)
    {

       
    }
}
